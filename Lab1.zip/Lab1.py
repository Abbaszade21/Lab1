Labarotoriya 1
